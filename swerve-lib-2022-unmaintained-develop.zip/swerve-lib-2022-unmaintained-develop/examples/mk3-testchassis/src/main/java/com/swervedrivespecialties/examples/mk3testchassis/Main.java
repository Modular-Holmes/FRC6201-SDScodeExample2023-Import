package com.swervedrivespecialties.examples.mk3testchassis;

import edu.wpi.first.wpilibj.RobotBase;

public class Main {
    public static void main(String[] args) {
        RobotBase.startRobot(Robot::new);
    }
}
